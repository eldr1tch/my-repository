<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @package MedinaVerdeEcoConstrucciones
 */
?>

<footer class="bg-dark text-white pt-4">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h5>Sobre Nosotros</h5>
                <p>Medina Verde Eco Construcciones se dedica a construir viviendas ecológicas utilizando materiales sustentables y técnicas innovadoras para reducir el impacto ambiental.</p>
            </div>
            <div class="col-md-4">
                <h5>Enlaces Rápidos</h5>
                <ul class="list-unstyled">
                    <li><a href="<?php echo home_url(); ?>" class="text-white">Inicio</a></li>
                    <li><a href="<?php echo home_url('/vision'); ?>" class="text-white">Visión</a></li>
                    <li><a href="<?php echo home_url('/mision'); ?>" class="text-white">Misión</a></li>
                    <li><a href="<?php echo home_url('/contacto'); ?>" class="text-white">Contacto</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h5>Contacto</h5>
                <ul class="list-unstyled">
                    <li><i class="fas fa-map-marker-alt"></i> Dirección: Calle Falsa 123, Ciudad, País</li>
                    <li><i class="fas fa-phone"></i> Teléfono: (123) 456-7890</li>
                    <li><i class="fas fa-envelope"></i> Email: info@medinaverde.com</li>
                </ul>
                <h5>Síguenos</h5>
                <ul class="list-unstyled list-inline">
                    <li class="list-inline-item"><a href="#" class="text-white"><i class="fab fa-facebook-f"></i></a></li>
                    <li class="list-inline-item"><a href="#" class="text-white"><i class="fab fa-twitter"></i></a></li>
                    <li class="list-inline-item"><a href="#" class="text-white"><i class="fab fa-instagram"></i></a></li>
                    <li class="list-inline-item"><a href="#" class="text-white"><i class="fab fa-linkedin"></i></a></li>
                </ul>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-12 text-center">
                <p>&copy; <?php echo date('Y'); ?> Medina Verde Eco Construcciones. Todos los derechos reservados.</p>
            </div>
        </div>
    </div>
</footer>

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<!-- Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<!-- Bootstrap JS -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    $(document).ready(function () {
        $('.navbar-nav>li>a').on('click', function () {
            $('.navbar-collapse').collapse('hide');
        });
        $('.navbar-toggler').on('click', function () {
            $('#navbarNav').collapse('toggle');
        });
    });
</script>

<?php wp_footer(); ?>
</body>
</html>
