<?php
/*
Template Name: Visión
*/
?>

<?php get_header(); ?>

<style>
    /* Estilos adicionales para la página de Visión */
    .page-template-vision {
        background: url('<?php echo get_template_directory_uri(); ?>/assets/img/background.jpg') no-repeat center center fixed;
        background-size: cover !important; /* Asegura que el fondo cubra completamente */
        color: white;
        padding: 50px 20px; /* Espacio alrededor del contenido */
        min-height: 100vh; /* Altura mínima igual a la altura de la ventana del navegador */
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        text-align: center; /* Alineación del texto al centro */
    }

    .page-template-vision h1,
    .page-template-vision h2,
    .page-template-vision h3,
    .page-template-vision p,
    .page-template-vision ul li {
        color: white;
    }

    .vision-content {
        max-width: 1200px; /* Ancho máximo del contenido */
        text-align: center;
    }

    .vision-image {
        width: 100%; /* Ancho al 100% del contenedor */
        height: auto; /* Altura automática proporcional al ancho */
        margin-bottom: 20px; /* Espacio inferior */
    }

    .vision-text {
        text-align: center; /* Alineación del texto al centro */
    }

    @media (min-width: 992px) {
        .vision-content {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .vision-row {
            display: flex;
            flex-direction: row;
            justify-content: center;
            align-items: center;
        }

        .vision-image {
            width: 50%; /* Ajuste del ancho de la imagen */
        }

        .vision-text {
            width: 50%; /* Ajuste del ancho del texto */
            margin-left: 20px; /* Espacio a la izquierda del texto */
            text-align: left; /* Alineación del texto a la izquierda */
        }
    }
</style>

<!-- Main content -->
<div class="container-fluid page-template-vision">
    <div class="vision-content">
        <div class="text-center">
            <h1 class="display-4">Nuestra Visión</h1>
            <p class="lead">Construyendo un futuro sostenible con innovación y responsabilidad.</p>
        </div>
        <div class="vision-row my-5">
            <div>
                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/vision2.jpg" class="img-fluid rounded vision-image" alt="Visión">
            </div>
            <div class="vision-text">
                <h2 class="h4">Nuestro Compromiso</h2>
                <p>En Medina Verde Eco Construcciones, nuestra visión es liderar el sector de la construcción sostenible, ofreciendo soluciones ecológicas y eficientes que respeten el medio ambiente y mejoren la calidad de vida de las personas.</p>
                <h3 class="h5 mt-4">Nuestros Valores</h3>
                <ul class="list-unstyled">
                    <li><i class="fas fa-seedling"></i> Sostenibilidad</li>
                    <li><i class="fas fa-tools"></i> Innovación</li>
                    <li><i class="fas fa-users"></i> Responsabilidad social</li>
                    <li><i class="fas fa-handshake"></i> Integridad</li>
                    <li><i class="fas fa-globe"></i> Conciencia ambiental</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- Additional JavaScript for interactivity if needed -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // JavaScript for any additional interactivity
    });
</script>

<?php get_footer(); ?>
