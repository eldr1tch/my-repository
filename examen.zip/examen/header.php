<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medina Verde Eco Construcciones</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <!-- Tema CSS -->
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style.css">
    <style>
        .navbar {
            padding-top: 1rem;
            padding-bottom: 1rem;
        }

        .navbar-brand {
            font-size: 1.5rem;
        }

        .navbar-nav {
            flex-direction: row;
        }

        .nav-item {
            margin-left: 20px;
        }

        .nav-link {
            font-size: 1.2rem;
            padding: 0.75rem 1rem;
        }

        .navbar-nav .dropdown-menu {
            position: static;
            float: none;
        }

        .dropdown:hover>.dropdown-menu {
            display: block;
        }

        /* Ajustes para el tamaño del carrusel */
        .carousel-item img {
            width: 100%;
            height: auto;
            max-height: 500px;
        }

        .post-content {
            font-size: 1.2rem;
        }

        .post h2 {
            font-size: 2rem;
        }

        .post-meta {
            font-size: 1rem;
        }

        @media (max-width: 991px) {
            .navbar-nav {
                flex-direction: column;
            }

            .nav-item {
                margin-left: 0;
            }

            .nav-link {
                font-size: 1rem;
                padding: 0.5rem 1rem;
            }
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
        <a class="navbar-brand" href="<?php echo home_url(); ?>">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/logo.jpg" alt="Medina Verde" style="height: 100px;">
        </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item active">
                        <a class="nav-link" href="<?php echo home_url(); ?>"><i class="fas fa-home"></i> Inicio <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo get_permalink(get_page_by_title('Contacto')); ?>"><i class="fas fa-users"></i> Contacto</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo get_permalink(get_page_by_title('Visión')); ?>"><i class="fas fa-eye"></i> Visión</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo get_permalink(get_page_by_title('Misión')); ?>"><i class="fas fa-bullseye"></i> Misión</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="catalogoDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-book"></i> Catálogo
                        </a>
                        <div class="dropdown-menu" aria-labelledby="catalogoDropdown">
                            <a class="dropdown-item" href="https://joa.jerez.laboratoriodiseno.cl/examen/proyectos/">Proyectos</a>
                            <a class="dropdown-item" href="https://joa.jerez.laboratoriodiseno.cl/examen/equipo/">Conoce nuestro equipo de trabajo</a>
                            <a class="dropdown-item" href="https://joa.jerez.laboratoriodiseno.cl/examen/materiales/">Materiales</a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Carousel -->
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img class="d-block w-100" src="<?php bloginfo('template_url'); ?>/imagenes/carrusel1.jpg" alt="Primera imagen">
                <div class="carousel-caption d-none d-md-block">
                    <h5>Revisa nuestros proyectos en el catálogo</h5>
                </div>
            </div>
            <div class="carousel-item">
                <img class="d-block w-100" src="<?php echo get_template_directory_uri(); ?>/imagenes/fotox.jpg" alt="Segunda imagen">
                <div class="carousel-caption d-none d-md-block">
                </div>
            </div>
            <div class="carousel-item">
                <img class="d-block w-100" src="<?php echo get_template_directory_uri(); ?>/imagenes/carrusel3.jpg" alt="Tercera imagen">
                <div class="carousel-caption d-none d-md-block">
                </div>
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Anterior</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Siguiente</span>
        </a>
    </div>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
