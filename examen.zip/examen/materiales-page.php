<?php
/*
Template Name: Materiales
*/
?>

<?php
    get_header();
?>

<div class="container my-5">
    <div class="row">
        <div class="col-md-12">
            <h1 class="text-center mb-5">Materiales para Construcción Ecológica</h1>
        </div>
    </div>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <?php
            // Array con la información de los materiales
            $materiales = array(
                array(
                    'nombre' => 'Bambú',
                    'descripcion' => 'Material altamente renovable, utilizado por su resistencia y flexibilidad.',
                    'imagen' => get_template_directory_uri() . '/assets/img/bambu.jpg'
                ),
                array(
                    'nombre' => 'Madera Reciclada',
                    'descripcion' => 'Madera reutilizada de construcciones anteriores, reduce la necesidad de talar nuevos árboles.',
                    'imagen' => get_template_directory_uri() . '/assets/img/madera_reciclada.jpg'
                ),
                array(
                    'nombre' => 'Hormigón Verde',
                    'descripcion' => 'Hormigón hecho con materiales reciclados y menos emisiones de CO2.',
                    'imagen' => get_template_directory_uri() . '/assets/img/hormigon_verde.jpg'
                ),
                array(
                    'nombre' => 'Ladrillos de Adobe',
                    'descripcion' => 'Ladrillos hechos de tierra cruda, eficaces para el aislamiento térmico.',
                    'imagen' => get_template_directory_uri() . '/assets/img/ladrillos_adobe.jpg'
                ),
                array(
                    'nombre' => 'Paja',
                    'descripcion' => 'Excelente aislante térmico, utilizada en paneles y techos.',
                    'imagen' => get_template_directory_uri() . '/assets/img/paja.jpg'
                ),
                array(
                    'nombre' => 'Plástico Reciclado',
                    'descripcion' => 'Usado en diferentes aplicaciones de construcción, reduce residuos plásticos.',
                    'imagen' => get_template_directory_uri() . '/assets/img/plastico_reciclado.jpg'
                ),
                array(
                    'nombre' => 'Paneles Solares',
                    'descripcion' => 'Generan energía limpia y renovable para las viviendas.',
                    'imagen' => get_template_directory_uri() . '/assets/img/paneles_solares.jpg'
                ),
                array(
                    'nombre' => 'Pinturas Ecológicas',
                    'descripcion' => 'Pinturas sin componentes tóxicos, hechas de materiales naturales.',
                    'imagen' => get_template_directory_uri() . '/assets/img/pinturas_ecologicas.jpg'
                )
            );

            // Bucle para mostrar la información de los materiales
            foreach ($materiales as $material) {
            ?>
                <div class="card mb-4">
                    <?php if ($material['imagen']): ?>
                        <img src="<?php echo esc_url($material['imagen']); ?>" class="card-img-top" alt="<?php echo esc_attr($material['nombre']); ?>">
                    <?php endif; ?>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo esc_html($material['nombre']); ?></h5>
                        <p class="card-text"><?php echo esc_html($material['descripcion']); ?></p>
                    </div>
                </div>
            <?php
            }
            ?>
        </div>
    </div>
</div>

<?php
    get_footer();
?>
