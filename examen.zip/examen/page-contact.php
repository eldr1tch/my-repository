<?php
/*
Template Name: Página de Contacto
*/

get_header();
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-12 col-md-8">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h1 class="card-title text-center mb-4">Contacto</h1>
                    <p class="lead text-center">Póngase en contacto con nosotros utilizando la información a continuación.</p>

                    <div class="contact-info mt-4">
                        <?php if (get_field('direccion')) : ?>
                            <div class="mb-3">
                                <p><i class="fas fa-map-marker-alt"></i> <strong>Dirección:</strong> <?php the_field('direccion'); ?></p>
                            </div>
                        <?php endif; ?>

                        <?php if (get_field('telefono')) : ?>
                            <div class="mb-3">
                                <p><i class="fas fa-phone"></i> <strong>Teléfono:</strong> <?php the_field('telefono'); ?></p>
                            </div>
                        <?php endif; ?>

                        <?php if (get_field('email')) : ?>
                            <div class="mb-3">
                                <p><i class="fas fa-envelope"></i> <strong>Email:</strong> <a href="mailto:<?php the_field('email'); ?>"><?php the_field('email'); ?></a></p>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Agregar un formulario de contacto -->
                    <div class="contact-form mt-5">
                        <h2 class="h4 mb-3">Formulario de Contacto</h2>
                        <form>
                            <div class="form-group">
                                <label for="nombre">Nombre</label>
                                <input type="text" class="form-control" id="nombre" placeholder="Ingrese su nombre">
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" class="form-control" id="email" placeholder="Ingrese su email">
                            </div>
                            <div class="form-group">
                                <label for="mensaje">Mensaje</label>
                                <textarea class="form-control" id="mensaje" rows="4" placeholder="Ingrese su mensaje"></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">Enviar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
get_footer();
?>
