<?php
/*
Template Name: Equipo
*/
?>

<?php
    get_header();
?>

<div class="container my-5">
    <div class="row">
        <div class="col-md-12">
            <h1 class="text-center mb-5">Nuestro Equipo</h1>
        </div>
    </div>
    <div class="row">
        <?php
        // Array con la información del equipo
        $equipo = array(
            array(
                'nombre' => 'Ana López',
                'cargo' => 'Arquitecta Sustentable',
                'imagen' => get_template_directory_uri() . '/assets/img/avatar.jpg'
            ),
            array(
                'nombre' => 'Carlos Pérez',
                'cargo' => 'Ingeniero Ambiental',
                'imagen' => get_template_directory_uri() . '/assets/img/avatar.jpg' // Reemplaza con la ruta correcta
            ),
            array(
                'nombre' => 'María González',
                'cargo' => 'Diseñadora de Interiores Ecológicos',
                'imagen' => get_template_directory_uri() . '/assets/img/avatar.jpg' // Reemplaza con la ruta correcta
            ),
            array(
                'nombre' => 'José Martínez',
                'cargo' => 'Constructor de Casas Verdes',
                'imagen' => get_template_directory_uri() . '/assets/img/avatar.jpg' // Reemplaza con la ruta correcta
            ),
            array(
                'nombre' => 'Laura Ramírez',
                'cargo' => 'Consultora de Energía Renovable',
                'imagen' => get_template_directory_uri() . '/assets/img/avatar.jpg' // Reemplaza con la ruta correcta
            ),
            array(
                'nombre' => 'Pedro Sánchez',
                'cargo' => 'Especialista en Materiales Reciclados',
                'imagen' => get_template_directory_uri() . '/assets/img/avatar.jpg' // Reemplaza con la ruta correcta
            )
        );

        // Bucle para mostrar la información del equipo
        foreach ($equipo as $persona) {
        ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <?php if ($persona['imagen']): ?>
                        <img src="<?php echo esc_url($persona['imagen']); ?>" class="card-img-top" alt="<?php echo esc_attr($persona['nombre']); ?>">
                    <?php endif; ?>
                    <div class="card-body text-center">
                        <h5 class="card-title"><?php echo esc_html($persona['nombre']); ?></h5>
                        <p class="card-text"><?php echo esc_html($persona['cargo']); ?></p>
                    </div>
                </div>
            </div>
        <?php
        }
        ?>
    </div>
</div>

<?php
    get_footer();
?>
