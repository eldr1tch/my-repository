<?php
/*
Template Name: Misión
*/
?>

<?php
get_header();
?>

<style>
    .mission-page {
        background-image: url('<?php echo get_template_directory_uri(); ?>/assets/img/background.jpg'); /* Ruta de la imagen de fondo */
        background-size: cover; /* Asegura que el fondo cubra completamente */
        background-position: center;
        background-attachment: fixed;
        color: #fff;
        padding: 60px 0;
        min-height: 100vh; /* Altura mínima de la sección */
        display: flex;
        align-items: center;
    }

    .mission-content {
        background-color: rgba(0, 0, 0, 0.7); /* Fondo semitransparente para el contenido */
        padding: 40px;
        border-radius: 10px;
        width: 100%;
    }

    .mission-content h1,
    .mission-content h2,
    .mission-content p {
        color: #fff; /* Asegurar que el texto sea legible */
    }
</style>

<div class="container-fluid mission-page">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10 mission-content">
                <div class="text-center">
                    <h1>Nuestra Misión</h1>
                    <p class="lead">Construir un futuro sostenible a través de viviendas ecológicas innovadoras y responsables.</p>
                </div>
                <div class="row mt-4">
                    <div class="col-md-6">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/mision.jpg" class="img-fluid" alt="Construcción Ecológica">
                    </div>
                    <div class="col-md-6">
                        <h2>Compromiso con el Medio Ambiente</h2>
                        <p>En Medina Verde Eco Construcciones, nos dedicamos a reducir el impacto ambiental de la construcción. Utilizamos materiales sostenibles y técnicas de construcción innovadoras que minimizan el uso de recursos naturales y reducen las emisiones de carbono.</p>
                        
                        <h2>Innovación y Calidad</h2>
                        <p>Nuestra misión es combinar innovación y calidad en cada proyecto. Nos esforzamos por desarrollar viviendas que no solo sean ecológicas, sino también funcionales, cómodas y duraderas. Creemos que la construcción sostenible es la clave para un futuro mejor.</p>
                        
                        <h2>Comunidades Sostenibles</h2>
                        <p>Promovemos la creación de comunidades sostenibles que respeten y convivan armoniosamente con el entorno natural. Nuestro objetivo es construir espacios que fomenten un estilo de vida saludable y ecológico para nuestros clientes y las futuras generaciones.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
get_footer();
?>
