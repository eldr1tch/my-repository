<?php
/*
Template Name: Proyectos
*/
?>

<?php
    get_header();
?>

<div class="container my-5">
    <div class="row">
        <?php
        // Consulta personalizada para obtener los proyectos
        $args = array(
            'post_type' => 'projects',
            'posts_per_page' => -1
        );
        $projects = new WP_Query($args);

        if ($projects->have_posts()) :
            while ($projects->have_posts()) : $projects->the_post();
                // Obtener los campos personalizados
                $imagen = get_field('imagen_del_proyecto');
                $ubicacion = get_field('ubicacion');
                $descripcion = get_field('descripcion_del_proyecto');
        ?>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <?php if ($imagen): ?>
                            <img src="<?php echo esc_url($imagen['url']); ?>" class="card-img-top" alt="<?php echo esc_attr($imagen['alt']); ?>">
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?php the_title(); ?></h5>
                            <?php if ($ubicacion): ?>
                                <h6 class="card-subtitle mb-2 text-muted"><?php echo esc_html($ubicacion); ?></h6>
                            <?php endif; ?>
                            <?php if ($descripcion): ?>
                                <p class="card-text"><?php echo esc_html($descripcion); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
        <?php
            endwhile;
            wp_reset_postdata();
        else :
        ?>
            <p><?php _e('No hay proyectos disponibles.'); ?></p>
        <?php endif; ?>
    </div>
</div>

<?php
    get_footer();
?>
