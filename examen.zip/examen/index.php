<?php
// Incluye el archivo header.php
get_header();
?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-12 col-md-8">
            <!-- Aquí comienza el Loop de WordPress -->
            <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                <div class="post card mb-4 shadow-sm">
                    <div class="card-body">
                        <h2 class="card-title"><?php the_title(); ?></h2>
                        <div class="post-meta text-muted mb-2">
                        </div>
                        <div class="post-content">
                            <div class="text-center">
                                <?php if (has_post_thumbnail()) : ?>
                                    <?php the_post_thumbnail('full', ['class' => 'img-fluid']); ?>
                                <?php endif; ?>
                            </div>
                            <?php the_content(); ?>
                        </div>
                    </div>
                </div>
            <?php endwhile; else : ?>
                <div class="alert alert-warning" role="alert">
                    <?php _e('Lo siento, no se encontraron entradas.'); ?>
                </div>
            <?php endif; ?>
            <!-- Aquí termina el Loop de WordPress -->
        </div>
    </div>
</div>

<?php
// Incluye el archivo footer.php
get_footer();
?>

<style>
    .post h2 {
        font-size: 2rem;
        color: #333;
    }

    .post-meta {
        font-size: 0.9rem;
    }

    .post-content {
        font-size: 1.1rem;
    }

    .text-center {
        text-align: center;
    }
</style>
