<?php
/* Template Name: Página de Registro */

get_header();
?>

<div class="container mt-5 pt-5 mb-5">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <h3 class="mb-4">Crear una cuenta</h3>
      <form method="post">
        <div class="form-group">
          <label for="reg_username">Nombre de usuario</label>
          <input type="text" name="reg_username" class="form-control" required>
        </div>
        <div class="form-group">
          <label for="reg_email">Correo electrónico</label>
          <input type="email" name="reg_email" class="form-control" required>
        </div>
        <div class="form-group">
          <label for="reg_password">Contraseña</label>
          <input type="password" name="reg_password" class="form-control" required>
        </div>
        <input type="submit" name="registrarse" value="Registrarse" class="btn btn-success">
      </form>

      <?php
      if (isset($_POST['registrarse'])) {
        $username = sanitize_user($_POST['reg_username']);
        $email = sanitize_email($_POST['reg_email']);
        $password = esc_attr($_POST['reg_password']);

        $errors = [];

        if (username_exists($username)) {
          $errors[] = 'Este nombre de usuario ya existe.';
        }

        if (email_exists($email)) {
          $errors[] = 'Este correo electrónico ya está registrado.';
        }

        if (empty($errors)) {
          $user_id = wp_create_user($username, $password, $email);
          if (!is_wp_error($user_id)) {
            echo '<p class="text-success mt-3">¡Usuario creado exitosamente! Ya puedes iniciar sesión.</p>';
          }
        } else {
          foreach ($errors as $err) {
            echo '<p class="text-danger mt-2">' . $err . '</p>';
          }
        }
      }
      ?>
    </div>
  </div>
</div>

<?php get_footer(); ?>
