<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
  <header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark py-3">
      <div class="container">
        <!-- LOGO -->
        <a class="navbar-brand" href="<?php echo home_url(); ?>">
          <?php
            $custom_logo_id = get_theme_mod('custom_logo');
            $logo = wp_get_attachment_image_src($custom_logo_id , 'full');
            if (has_custom_logo()) {
              echo '<img src="' . esc_url($logo[0]) . '" class="img-fluid intermaq-logo" alt="' . get_bloginfo('name') . '">';
            } else {
              bloginfo('name');
            }
          ?>
        </a>

        <!-- BOTÓN RESPONSIVE -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#mainNavbar"
          aria-controls="mainNavbar" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <!-- CONTENIDO DEL NAV -->
        <div class="collapse navbar-collapse" id="mainNavbar">
          <?php
            wp_nav_menu(array(
              'theme_location' => 'main_menu',
              'depth' => 2,
              'container' => false,
              'menu_class' => 'navbar-nav mr-auto',
              'fallback_cb' => 'WP_Bootstrap_Navwalker::fallback',
              'walker' => new WP_Bootstrap_Navwalker()
            ));
          ?>

          <!-- Íconos -->
          <ul class="navbar-nav ml-3">

            <li class="nav-item">
              <a class="nav-link text-warning" href="<?php echo home_url('/carrito'); ?>">
                <i class="fas fa-shopping-cart"></i>
                <span id="cart-count" class="badge badge-warning ml-1">0</span>
              </a>
            </li>

            <li class="nav-item">
              <a class="nav-link text-warning" href="https://www.facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-warning" href="https://www.instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-warning" href="https://wa.me/56912345678" target="_blank"><i class="fab fa-whatsapp"></i></a>
            </li>

          </ul>
        </div>
      </div>
    </nav>
  </header>
