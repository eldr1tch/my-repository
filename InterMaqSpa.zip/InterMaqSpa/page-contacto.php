<?php
/* Template Name: Contacto */
get_header();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['nombre'])) {
  $nombre   = sanitize_text_field($_POST['nombre']);
  $correo   = sanitize_email($_POST['correo']);
  $telefono = sanitize_text_field($_POST['telefono']);
  $mensaje  = sanitize_textarea_field($_POST['mensaje']);

  $to = get_option('admin_email');
  $subject = "Nuevo mensaje de contacto desde el sitio";
  $headers = ["From: $nombre <$correo>", "Reply-To: $correo"];
  $body = "Nombre: $nombre\nCorreo: $correo\nTeléfono: $telefono\n\nMensaje:\n$mensaje";

  if (wp_mail($to, $subject, $body, $headers)) {
    echo '<div class="container mt-4"><div class="alert alert-success">Gracias por tu mensaje. Te responderemos pronto.</div></div>';
  } else {
    echo '<div class="container mt-4"><div class="alert alert-danger">Hubo un error al enviar tu mensaje. Intenta nuevamente.</div></div>';
  }
}
?>

<section class="py-5" style="background-color: #0f0f0f; color: #fff;">
  <div class="container">
    <div class="text-center mb-5">
      <h1 class="display-4 text-warning font-weight-bold" style="font-family: 'Cinzel', serif;">Contáctanos</h1>
      <p class="lead">Estamos aquí para responder cualquier duda o requerimiento sobre repuestos para maquinaria pesada.</p>
      <hr class="bg-warning" style="width: 60px; height: 4px; border: none; margin: 20px auto;">
    </div>

    <div class="row justify-content-center">
      <div class="col-lg-8">
        <form action="" method="post" class="p-4 border border-warning rounded" style="background-color: #1a1a1a;">
          <div class="form-group">
            <label for="nombre">Nombre</label>
            <input type="text" class="form-control" id="nombre" name="nombre" required>
          </div>

          <div class="form-group">
            <label for="correo">Correo electrónico</label>
            <input type="email" class="form-control" id="correo" name="correo" required>
          </div>

          <div class="form-group">
            <label for="telefono">Teléfono</label>
            <input type="text" class="form-control" id="telefono" name="telefono">
          </div>

          <div class="form-group">
            <label for="mensaje">Mensaje</label>
            <textarea class="form-control" id="mensaje" name="mensaje" rows="5" required></textarea>
          </div>

          <button type="submit" class="btn btn-warning mt-3">Enviar mensaje</button>
        </form>
      </div>
    </div>
  </div>
</section>

<?php get_footer(); ?>