<?php
/* Template Name: Sobre Nosotros */
get_header();
?>

<section class="py-5" style="background-color: #0f0f0f; color: #fff;">
  <div class="container">
    <div class="text-center mb-5">
      <h1 class="display-4 text-warning font-weight-bold" style="font-family: 'Cinzel', serif;">Sobre Nosotros</h1>
      <hr class="bg-warning" style="width: 60px; height: 4px; border: none; margin: 20px auto;">
    </div>

    <div class="row justify-content-center">
      <div class="col-lg-10">
        <p class="lead">Somos una empresa dedicada a la comercialización de repuestos para maquinaria pesada, con una destacada trayectoria en el sector y un fuerte compromiso con la calidad y la excelencia. En Chile, representamos de manera exclusiva a <strong>JCB</strong>. Esta reconocida marca británica se caracteriza por su constante innovación, alto desempeño y estrictos estándares de seguridad.</p>

        <p>Desde nuestra fundación, hemos trabajado con dedicación para posicionarnos como un referente en el suministro de repuestos para maquinaria pesada. Nuestra evolución ha estado marcada por el compromiso con nuestros clientes y la constante búsqueda de la excelencia en cada servicio que entregamos.</p>

        <p>Respaldamos cada uno de nuestros productos con garantía, asegurando un servicio confiable y duradero. Gracias a nuestro conocimiento técnico y experiencia, brindamos soluciones eficientes y adaptadas a las necesidades específicas de cada cliente.</p>

        <p>Nos esforzamos por ser más que un proveedor; aspiramos a convertirnos en un aliado estratégico y confiable para cada uno de nuestros socios comerciales. Lo invitamos a conocernos y descubrir por qué somos la mejor opción para sus necesidades en repuestos de maquinaria pesada. <strong>Contáctenos hoy mismo</strong> para recibir asesoría personalizada.</p>
      </div>
    </div>
  </div>
</section>

<?php get_footer(); ?>
