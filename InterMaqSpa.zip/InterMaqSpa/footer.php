<!-- Footer -->
<footer class="pt-5 pb-4" style="background-color: #0f0f0f; color: #fff; border-top: 2px solid #ffc107;">
  <div class="container">
    <div class="row text-md-left align-items-start justify-content-between">

      <!-- Logo -->
      <div class="col-lg-3 col-md-6 mb-4 mb-md-0 text-center text-lg-left">
        <?php
          $custom_logo_id = get_theme_mod('custom_logo');
          $logo = wp_get_attachment_image_src($custom_logo_id , 'full');
          if (has_custom_logo()) {
            echo '<img src="' . esc_url($logo[0]) . '" class="img-fluid mb-3" style="max-width: 180px;" alt="' . get_bloginfo('name') . '">';
          } else {
            bloginfo('name');
          }
        ?>
      </div>

      <!-- Nuestra empresa -->
      <div class="col-lg-4 col-md-6 mb-4 mb-md-0">
        <h5 class="text-uppercase text-warning mb-3" style="font-family: 'Cinzel', serif;">Nuestra Empresa</h5>
        <p class="small text-light">
          Somos una empresa dedicada a la venta de repuestos para maquinaria pesada, representante oficial de JCB en Chile. Ofrecemos productos garantizados y soluciones eficientes, con un firme compromiso con la calidad y el servicio.
        </p>
      </div>

      <!-- Enlaces -->
      <div class="col-lg-2 col-md-6 mb-4 mb-md-0">
        <h5 class="text-uppercase text-warning mb-3" style="font-family: 'Cinzel', serif;">Enlaces</h5>
        <ul class="list-unstyled small">
          <li><a href="/wordpress/nosotros" class="text-light">Sobre Nosotros</a></li>
          <li><a href="/wordpress/contacto/" class="text-light">Contacto</a></li>
        </ul>
      </div>

      <!-- Contacto -->
      <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
        <h5 class="text-uppercase text-warning mb-3" style="font-family: 'Cinzel', serif;">Contáctanos</h5>
        <ul class="list-unstyled small text-light">
          <li><i class="fas fa-home mr-2 text-warning"></i> Calle Principal 123, Zona Industrial</li>
          <li><i class="fas fa-envelope mr-2 text-warning"></i> info@maquinariaconstruccion.com</li>
          <li><i class="fas fa-phone mr-2 text-warning"></i> +56 9 9999 9999</li>
        </ul>
      </div>
    </div>

    <!-- Línea separadora -->
    <hr class="my-4" style="border-color: #ffc107;">

    <!-- Redes sociales -->
    <div class="d-flex justify-content-center justify-content-md-start mb-3">
      <a href="https://www.facebook.com" class="text-warning mr-4"><i class="fab fa-facebook-f fa-lg"></i></a>
      <a href="https://www.instagram.com" class="text-warning mr-4"><i class="fab fa-instagram fa-lg"></i></a>
      <a href="https://wa.me/56912345678" class="text-warning"><i class="fab fa-whatsapp fa-lg"></i></a>
    </div>

    <!-- Derechos -->
    <p class="mb-0 small text-center text-md-right text-light">&copy; <?php echo date("Y"); ?> Maquinaria Construcción. Todos los derechos reservados.</p>
  </div>
</footer>

<?php wp_footer(); ?>

<script>
  function actualizarContadorCarrito() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const countEl = document.getElementById('cart-count');
    if (countEl) countEl.textContent = cart.length;
  }

  document.addEventListener('DOMContentLoaded', () => {
    actualizarContadorCarrito();

    const botonesAgregar = document.querySelectorAll('.add-to-cart');
    botonesAgregar.forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.dataset.id;
        const title = btn.dataset.title;
        const price = btn.dataset.price;
        const image = btn.dataset.image;

        let cart = JSON.parse(localStorage.getItem('cart')) || [];

        const existe = cart.find(item => item.id === id);
        if (!existe) {
          cart.push({ id, title, price, image, qty: 1 });
          alert('Producto agregado al carrito');
        } else {
          existe.qty += 1;
          alert('Producto agregado');
        }
        localStorage.setItem('cart', JSON.stringify(cart));
        actualizarContadorCarrito();
      });
    });
  });
</script>

</body>
</html>
