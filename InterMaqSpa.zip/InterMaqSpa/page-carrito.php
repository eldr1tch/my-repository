<?php
/* Template Name: Carrito */
get_header();
?>

<style>
  body {
    background-color: #0f0f0f;
    color: #fff;
  }

  .carrito-wrapper {
    max-width: 900px;
    margin: 100px auto;
    background-color: #1e1e1e;
    border: 2px solid #ffc107;
    border-radius: 10px;
    padding: 30px;
    box-shadow: 0 0 20px rgba(255, 193, 7, 0.2);
  }

  .carrito-wrapper h2 {
    color: #ffc107;
    font-family: 'Cinzel', serif;
    margin-bottom: 30px;
    text-align: center;
  }

  .carrito-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 20px;
    border-bottom: 1px solid #444;
    padding-bottom: 10px;
  }

  .carrito-item img {
    width: 80px;
    height: auto;
    margin-right: 20px;
    border: 1px solid #ccc;
    background-color: #fff;
  }

  .carrito-item .info {
    flex-grow: 1;
  }

  .carrito-item .actions {
    text-align: right;
  }

  .btn-remove {
    background-color: transparent;
    color: #ffc107;
    border: none;
  }

  .btn-remove:hover {
    color: red;
  }

  .qty-controls {
    display: flex;
    align-items: center;
    margin-top: 5px;
  }

  .qty-controls button {
    background: #ffc107;
    color: #121212;
    border: none;
    padding: 2px 8px;
    font-weight: bold;
    margin: 0 5px;
    cursor: pointer;
  }

  .total {
    font-size: 1.4rem;
    color: #ffc107;
    text-align: right;
    margin-top: 30px;
  }

  .btn-clear, .btn-whatsapp {
    margin-top: 20px;
    display: inline-block;
    background-color: #ffc107;
    border: none;
    color: #121212;
    font-weight: bold;
    padding: 10px 20px;
    margin-right: 10px;
    text-decoration: none;
  }

  .btn-clear:hover, .btn-whatsapp:hover {
    background-color: #e0ac06;
  }
</style>

<div class="carrito-wrapper">
  <h2><i class="fas fa-shopping-cart"></i> Mi Carrito</h2>
  <div id="carrito-items"></div>
  <div class="total">Total: $<span id="total-compra">0</span></div>
  <button class="btn-clear" id="vaciar-carrito">Vaciar Carrito</button>
  <a href="#" class="btn-whatsapp" id="finalizar-whatsapp" target="_blank"><i class="fab fa-whatsapp"></i> Finalizar pedido por WhatsApp</a>
</div>

<script>
  document.addEventListener('DOMContentLoaded', function () {
    const carritoContainer = document.getElementById('carrito-items');
    const totalCompra = document.getElementById('total-compra');
    const btnVaciar = document.getElementById('vaciar-carrito');
    const btnWhatsApp = document.getElementById('finalizar-whatsapp');

    function renderCarrito() {
      let cart = JSON.parse(localStorage.getItem('cart')) || [];
      carritoContainer.innerHTML = '';
      let total = 0;

      if (cart.length === 0) {
        carritoContainer.innerHTML = '<p>No hay productos en el carrito.</p>';
        btnWhatsApp.style.display = 'none';
        return;
      } else {
        btnWhatsApp.style.display = 'inline-block';
      }

      cart.forEach((item, index) => {
        const subtotal = parseFloat(item.price) * item.qty;
        total += subtotal;

        const itemHTML = `
          <div class="carrito-item">
            <img src="${item.image}" alt="${item.title}">
            <div class="info">
              <h5>${item.title}</h5>
              <p>Precio: $${item.price}</p>
              <div class="qty-controls">
                <button class="decrease" data-index="${index}">−</button>
                <span>${item.qty}</span>
                <button class="increase" data-index="${index}">+</button>
              </div>
            </div>
            <div class="actions">
              <button class="btn-remove" data-index="${index}"><i class="fas fa-times"></i></button>
            </div>
          </div>
        `;
        carritoContainer.innerHTML += itemHTML;
      });

      totalCompra.textContent = total;

      // Generar link de WhatsApp
      let mensaje = "Hola, quiero realizar un pedido:\n";
      cart.forEach(item => {
        mensaje += `- ${item.title} (x${item.qty}) - $${item.price} c/u\n`;
      });
      mensaje += `\nTotal: $${total}`;
      const numero = "56956131546";
      btnWhatsApp.href = `https://wa.me/${numero}?text=${encodeURIComponent(mensaje)}`;
    }

    carritoContainer.addEventListener('click', function (e) {
      let cart = JSON.parse(localStorage.getItem('cart')) || [];
      if (e.target.classList.contains('btn-remove')) {
        const index = e.target.dataset.index;
        cart.splice(index, 1);
      } else if (e.target.classList.contains('increase')) {
        const index = e.target.dataset.index;
        cart[index].qty += 1;
      } else if (e.target.classList.contains('decrease')) {
        const index = e.target.dataset.index;
        if (cart[index].qty > 1) {
          cart[index].qty -= 1;
        } else {
          cart.splice(index, 1);
        }
      }
      localStorage.setItem('cart', JSON.stringify(cart));
      renderCarrito();
      const countEl = document.getElementById('cart-count');
      if (countEl) countEl.textContent = cart.reduce((acc, item) => acc + item.qty, 0);
    });

    btnVaciar.addEventListener('click', function () {
      localStorage.removeItem('cart');
      renderCarrito();
      const countEl = document.getElementById('cart-count');
      if (countEl) countEl.textContent = 0;
    });

    renderCarrito();
  });
</script>

<?php get_footer(); ?>
