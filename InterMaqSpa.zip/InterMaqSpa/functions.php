<?php
// Cargar estilos y scripts necesarios
function intermaqspa_scripts() {
  // jQuery primero (de WordPress)
  wp_enqueue_script('jquery');

  // Popper.js (necesario para Bootstrap)
  wp_enqueue_script(
    'popper-js',
    'https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.1/umd/popper.min.js',
    ['jquery'],
    null,
    true
  );

  // Bootstrap JS
  wp_enqueue_script(
    'bootstrap-js',
    'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js',
    ['jquery', 'popper-js'],
    null,
    true
  );

  // Bootstrap CSS
  wp_enqueue_style(
    'bootstrap-css',
    'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'
  );

  // Font Awesome
  wp_enqueue_style(
    'fontawesome',
    'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css'
  );

  // Google Fonts
  wp_enqueue_style(
    'google-fonts',
    'https://fonts.googleapis.com/css2?family=Cinzel:wght@400;700&family=Lora:wght@400;700&display=swap',
    [],
    null
  );

  // Estilos del tema
wp_enqueue_style('main-style', get_stylesheet_uri());

}
add_action('wp_enqueue_scripts', 'intermaqspa_scripts');

// Registrar menús
function intermaqspa_register_menus() {
  register_nav_menus([
    'main_menu' => __('Menú Principal', 'intermaqspa'),
  ]);
}
add_action('after_setup_theme', 'intermaqspa_register_menus');

// Soporte para logo
add_theme_support('custom-logo', [
  'height'      => 60,
  'width'       => 200,
  'flex-height' => true,
  'flex-width'  => true,
  'header-text' => ['site-title', 'site-description'],
]);

// Soporte para miniaturas
add_theme_support('post-thumbnails');

// Fondo personalizado
function intermaqspa_custom_body_background() {
  $bg_url = get_template_directory_uri() . '/assets/img/fondo.png';
  echo "<style>
    body {
      background: url('{$bg_url}') no-repeat center center fixed;
      background-size: cover;
      background-color: #0f0f0f;
      color: #eaeaea;
    }
  </style>";
}
add_action('wp_head', 'intermaqspa_custom_body_background');

add_action('init', 'bloquear_acceso_wp_admin');


// Incluir Navwalker
require_once get_template_directory() . '/class-wp-bootstrap-navwalker.php';



