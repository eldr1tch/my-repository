<?php get_header(); ?>

<main>

  <!-- HERO DE BIENVENIDA -->
<section class="hero-section text-center text-light d-flex align-items-center justify-content-center" style="min-height: 70vh;">
  <div class="container">
    <h1 class="display-4 font-weight-bold text-warning">Soluciones en maquinaria confiables y robustas</h1>
    <p class="lead mt-3">InterMaqSpa ofrece equipos de calidad para la industria y la construcción. Confiabilidad, potencia y respaldo técnico.</p>
    <a href="#productos" class="btn btn-warning mt-4">Ver Productos</a>
  </div>
</section>

  <!-- BENEFICIOS / PILARES -->
  <section class="py-5 bg-dark text-light">
    <div class="container">
      <div class="row text-center">
        <div class="col-md-4 mb-4">
          <i class="fas fa-tools fa-3x text-warning mb-3"></i>
          <h5 class="font-weight-bold">Equipos de alto rendimiento</h5>
          <p>Máquinas confiables, diseñadas para trabajar en condiciones exigentes.</p>
        </div>
        <div class="col-md-4 mb-4">
          <i class="fas fa-headset fa-3x text-warning mb-3"></i>
          <h5 class="font-weight-bold">Soporte técnico especializado</h5>
          <p>Asistencia profesional y repuestos disponibles para todos nuestros equipos.</p>
        </div>
        <div class="col-md-4 mb-4">
          <i class="fas fa-handshake fa-3x text-warning mb-3"></i>
          <h5 class="font-weight-bold">Confianza y compromiso</h5>
          <p>Más de 10 años en el rubro entregando soluciones reales a nuestros clientes.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- SECCIÓN DE PRODUCTOS -->
<section id="productos" class="py-5" style="margin-top: 60px;">

  <div class="container">
    <div class="text-center mb-5">
      <h2 class="display-4 text-warning font-weight-bold">Nuestros Productos</h2>
      <p class="text-light">Explora nuestra línea de repuestos y soluciones confiables para maquinaria pesada.</p>
    </div>

    <div class="row">
      <?php
      $productos = new WP_Query(array(
        'post_type' => 'productos',
        'posts_per_page' => 5
      ));
      if ($productos->have_posts()):
        while ($productos->have_posts()): $productos->the_post();
          $imagen = get_field('imagen');
      ?>
        <div class="col-md-4 mb-4">
          <div class="card h-100 shadow-sm border-0 bg-dark text-light">
            <?php if ($imagen): ?>
              <img src="<?php echo esc_url($imagen); ?>" class="card-img-top p-2" alt="Imagen del producto" style="max-height: 260px; object-fit: contain;">
            <?php endif; ?>
            <div class="card-body d-flex flex-column justify-content-between">
            <h5 class="card-title text-warning"><?php the_title(); ?></h5>

              <p class="card-text text-muted small"><?php the_field('descripcion'); ?></p>
              <p class="h5 font-weight-bold text-warning">$<?php the_field('precio'); ?></p>

              <div class="mt-3 d-flex justify-content-between">
                <button class="btn btn-outline-warning btn-sm add-to-cart"
                  data-id="<?php the_ID(); ?>"
                  data-title="<?php the_title(); ?>"
                  data-price="<?php the_field('precio'); ?>"
                  data-image="<?php echo esc_url($imagen); ?>">
                  <i class="fas fa-cart-plus"></i> Agregar al carrito
                </button>
                <a href="<?php the_permalink(); ?>" class="btn btn-warning btn-sm">
                  Ver detalles
                </a>
              </div>
            </div>
          </div>
        </div>
      <?php
        endwhile;
        wp_reset_postdata();
      endif;
      ?>
    </div>
  </div>
</section>


</section>


</main>

<?php get_footer(); ?>
